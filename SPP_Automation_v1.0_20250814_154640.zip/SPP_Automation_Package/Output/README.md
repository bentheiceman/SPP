# Output Folder

This folder will contain the generated Excel files from the SPP automation tool.

Files will be named in the format:
`{Vendor_Number(s)} - {Vendor_Name} - {Month} {Year}.xlsm`

Examples:
- `52889 - BOXER_HOME_LLC - Apr 2025.xlsm`
- `52889_11833 - Multiple_Vendors - May 2025.xlsm`

The files are ready to be emailed to suppliers as monthly performance reports.
