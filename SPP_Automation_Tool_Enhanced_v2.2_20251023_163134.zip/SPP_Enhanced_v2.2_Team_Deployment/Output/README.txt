Generated SPP reports will be saved in this folder.
